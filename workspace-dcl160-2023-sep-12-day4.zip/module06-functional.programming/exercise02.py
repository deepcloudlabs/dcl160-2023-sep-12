"""
Procedural Programming: function      -> hierarchical
OOP                   : class/object  -> object network
Functional Programming: a) Higher-Order Function
                        b) Pure Function
                        Pipeline -> HoF composition
"""