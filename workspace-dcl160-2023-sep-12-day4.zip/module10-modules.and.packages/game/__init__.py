from game.mastermind import create_secret

print("game module is loaded!")

secret = create_secret(3)