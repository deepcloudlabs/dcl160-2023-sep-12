from game.mastermind import mastermind_main

mastermind_main()