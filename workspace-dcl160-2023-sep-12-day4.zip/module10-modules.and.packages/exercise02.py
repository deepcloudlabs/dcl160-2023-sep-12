from utility.numeric import fun

sequence = fun(7)
print(sequence)