from utility.dictionary import search_in_dictionary

for word in search_in_dictionary("\w{12,}"):
    print(word)
