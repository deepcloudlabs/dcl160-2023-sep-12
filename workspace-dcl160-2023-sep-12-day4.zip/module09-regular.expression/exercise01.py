"""
Validation Rules
Invariants
Business Rule
Constraint
Language -> Regular Expression -> pattern: . + * ? [] {} \d \w ...
word ? language
"""