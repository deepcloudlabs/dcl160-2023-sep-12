def sun(x, y, z):
    return x + y * z


print(f"sun(1,2,3): {sun(1, 2, 3)}")
print(f"sun(z=1,y=2,x=3): {sun(z=1,y=2,x=3)}")
