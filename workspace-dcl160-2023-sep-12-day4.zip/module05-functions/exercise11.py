secret = 3615

for i, digit in enumerate(str(secret)):
    print(i, digit)
