def sun(x=1001, y=2002, z=3003):
    return x + y * z


print(f"sun(): {sun(y=5005)}")
