"""
Failure
1. Type  I Error -> Fix
2. Type II Error -> UI |-> User / DB / File
"""