import pandas as pd

df = pd.read_csv("employees_pandas.csv")
print(df)