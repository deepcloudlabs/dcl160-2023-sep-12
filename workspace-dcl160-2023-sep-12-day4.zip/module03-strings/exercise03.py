full_name = "kate austen"
print(full_name[:6])
print(full_name[0:6:1])
print(full_name[6:])
print(full_name[6:11:1])
print(full_name[::3])
print(full_name[0:11:3])
