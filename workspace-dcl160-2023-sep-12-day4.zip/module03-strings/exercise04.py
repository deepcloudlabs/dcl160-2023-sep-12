full_name = "kate austen"
for c in full_name:
    if not c.isspace():
        print(c)
