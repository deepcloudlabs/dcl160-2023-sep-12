"""
OOP:
I) Abstraction: Class -> Object ✔
                encapsulation: data/state <-- method ✔
                design principle: information hiding ✔
II) Inheritance -> Re-usability ✔
III) Polymorphism -> Agility ✔
                     Open/Closed Principle
"""