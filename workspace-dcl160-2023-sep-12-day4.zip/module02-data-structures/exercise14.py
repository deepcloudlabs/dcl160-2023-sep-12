names = ["jack", "kate", "james", "sun", "jin", "ben"]
names[2:5] = ["james sawyer", "sun kwon", "jin kwon"]
print(names)
names[2:5] = []
print(names)
