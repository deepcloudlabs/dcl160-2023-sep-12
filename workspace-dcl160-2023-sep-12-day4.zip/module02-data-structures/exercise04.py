# tuple
numbers = (4, 8, 42, 4, 15, 23, 16, 15, 23, 16, 8, 4)
print(len(numbers))
print(f"numbers.count(4):{numbers.count(4)}")
print(f"numbers.count(8):{numbers.count(8)}")
print(f"numbers.index(4):{numbers.index(4)}")
print(f"108 in numbers:{108 in numbers}")
# set does not allow duplicates
set_numbers = {4, 8, 42, 4, 15, 23, 16, 15, 23, 16, 8, 4}
print(len(set_numbers))
