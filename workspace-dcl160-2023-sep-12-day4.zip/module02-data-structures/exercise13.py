numbers = (4,8,15,16,23,42)
print(numbers)
sliced_numbers = numbers[1:5:2]
print(sliced_numbers)
numbers2 = numbers[0::2]
print(numbers2)
numbers3 = numbers[1::2]
print(numbers3)
numbers4 = numbers[::-1]
print(numbers4)
