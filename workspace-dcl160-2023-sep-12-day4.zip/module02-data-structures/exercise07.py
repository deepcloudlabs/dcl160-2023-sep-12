numbers = (4, 8, 15, 16, 23, 42)
first, second, *remaining = numbers  # unpacking
print(numbers)
print(first)
print(second)
print(remaining)
