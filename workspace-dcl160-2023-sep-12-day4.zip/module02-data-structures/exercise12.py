names = ("jack", "kate", "james", "sun", "jin", "ben", "john",
          "charlie", "desmond", "claire", "juliet", "richard", "shannon")

