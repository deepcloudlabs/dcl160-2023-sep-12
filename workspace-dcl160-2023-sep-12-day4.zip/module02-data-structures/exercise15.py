names = ["jack", "kate", "james", "sun", "jin", "ben"]
print(names)
del names[3]
print(names)
