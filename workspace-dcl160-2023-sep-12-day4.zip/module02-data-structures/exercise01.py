x = 42  # scalar
"""
    LINEAR COLLECTION:
      i) TUPLE -> numbers = (4,8,15,16,23,42) : immutable
     ii) LIST  -> numbers = [4,8,15,16,23,42] : mutable, allows duplicates 
    iii) SET   -> numbers = {4,8,15,16,23,42} : mutable, unique
    ASSOCIATIVE COLLECTION:
    DICTIONARY
    {"izmir": 232, "istanbul": {"anadolu": 216, "avrupa": 212}, "ankara": 312 }
"""
