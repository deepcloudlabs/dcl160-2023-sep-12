names = ["jack", "kate", "james", "sun", "jin", "ben"]
print(names)
names.append("juliet")
names.append("claire")
names.append("shannon")
print(names)
print(names)
names.remove("claire")
print(names)
print(names[3])
print(names.pop(3))
print(names)
names[:]=[]
del names[::2]
print(names)
