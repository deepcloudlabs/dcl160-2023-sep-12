"""
 1) if / elif / else ✔
 2) loops:
     i) regular loops: for -> tuple/list/str
    ii) irregular    : while -> conditions
"""